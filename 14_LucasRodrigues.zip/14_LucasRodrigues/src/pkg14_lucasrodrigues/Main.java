/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg14_lucasrodrigues;

import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class Main {

    
    public static void main(String[] args) {
        
        
        Scanner scanner = new Scanner (System.in);
        
        System.out.println ("Numeor do mes e diremos qual é:");
        int pedido;
        pedido = scanner.nextInt();
        switch(pedido){
        case 1: 
            System.out.println ("Janeiro");
            System.exit(0);
        case 2:
            System.out.println ("Fevereiro");
            System.exit(0);
        case 3: 
            System.out.println ("Março");
            System.exit(0);
        case 4: 
            System.out.println ("Abril");
            System.exit(0);
        case 5: 
            System.out.println ("Maio");
            System.exit(0);
        case 6: 
            System.out.println ("Junho");
            System.exit(0);
        case 7: 
            System.out.println ("Julho");
            System.exit(0);
        case 8: 
            System.out.println ("Agosto");
            System.exit(0);
        case 9: 
            System.out.println ("Setembro");
            System.exit(0);
        case 10: 
            System.out.println ("Outubro");
            System.exit(0);
        case 11: 
            System.out.println ("Novembro");
            System.exit(0);
        case 12: 
        System.out.println ("Dezembro");
        System.exit(0);
        }
        
    }
    
}
