/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg13_lucasrodrigues;

import java.util.Scanner;
import javax.swing.JOptionPane;
import static jdk.nashorn.tools.ShellFunctions.input;

/**
 *
 * @author aluno
 */
public class Main {

    
    public static void main(String[] args) {
        
        int p;
        int u;
        
        JOptionPane.showMessageDialog(null,"Digite dois numero inteiros e iremos imprimir todos os números que estão entre o primeiro e o segundo número informado");
        String input = JOptionPane.showInputDialog("Primeiro Numero:");
        p = Integer.parseInt(input);
        String input2 = JOptionPane.showInputDialog("Segundo numero Numero:");
        u = Integer.parseInt(input2);
        
        
        
        
        
        do {
            for (int i = p+1; i < u;i++){
            
        JOptionPane.showMessageDialog(null,i);
        
            }
        }while( p < u && u < p);
        
        
        
         
        
        
        
    }
    
}
