/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg17_lucasrodrigues;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class Main {

    
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner (System.in);
        int n;
        int resultado;
        System.out.println ("Digite o umero da sua tabuada :");
        n = scanner.nextInt();
        
        FileWriter arq = new FileWriter ("C:\\Users\\aluno\\DeskTop\\TabuadaDe["+n+"].txt");
        PrintWriter gravarArq = new PrintWriter(arq);
        gravarArq.printf("Tabuada de "+n+ "%n");
        for(int i = 0; i <=10;i++){
           resultado = n*i;
        gravarArq.printf(n+" x " +i+ " = " + resultado + "%n");
        
        }
        
        arq.close();
       
        
        
        
        
    }
    
}
