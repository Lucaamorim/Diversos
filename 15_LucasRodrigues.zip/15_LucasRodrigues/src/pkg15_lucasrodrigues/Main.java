/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg15_lucasrodrigues;

import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class Main {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        int horasTrabalhadas;
        double ganhaPorHora;
        
        
        
        System.out.println ("Horas Trabalhadas:");
        horasTrabalhadas = scanner.nextInt();
        System.out.println ("Quanto tu ganha por Hora: ");
        ganhaPorHora = scanner.nextDouble();
        
        double salarioBruto = horasTrabalhadas*ganhaPorHora;
         
         
         
        double descIR = salarioBruto*11/100;
        double descINSS = salarioBruto*8/100;
        double descSindicato = (salarioBruto*5/100);
        double salarioLiquido = ((salarioBruto - descIR)-descINSS)+descSindicato;
         System.out.println ("Salario Bruto: " + salarioBruto);
         System.out.println ("Descontos:");
        System.out.println ("IR: " + descIR);
        System.out.println ("ISS: " + descINSS);
        System.out.println ("Sindicato: " + descSindicato);
         System.out.println ("Salario Liquido: " + salarioLiquido);
        
        
    }
    
}
