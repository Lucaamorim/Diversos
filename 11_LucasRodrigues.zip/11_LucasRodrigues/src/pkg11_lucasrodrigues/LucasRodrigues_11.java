/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg11_lucasrodrigues;

import java.util.Scanner;


public class LucasRodrigues_11 {
    public static void main(String[] args) {
    Scanner scanner = new Scanner (System.in);
        
        int dia;
        int ano;
        int meses;
        int resultado;
        
        
        System.out.println ("Digite seu :");
        System.out.println ("Ano :");
        ano = scanner.nextInt();
        System.out.println ("Meses :");
        meses = scanner.nextInt();
        System.out.println ("Dias :");
        dia = scanner.nextInt();
        resultado = (ano*360) + (meses*30) + dia;
        System.out.println ("Dias que foram vividos e nunca mais esquecidos :" + resultado);
    
}
}