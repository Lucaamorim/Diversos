/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg16_lucasrodrigues;

import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class Main {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        String nomeJ1;
        String nomeJ2;
        String nomeP1;
        String nomeP2;
        String nomeP3;
        String nomeP4;
        String nomeP5;
        String nomeFilme;
        int numeroPistas= 0;
        String resposta="";
        
        System.out.println ("Jogador 1, Digite seu nome e logo em seguida o nome do Filme e 5 pistas para ele:");
        System.out.print ("Jogador 1:");
        nomeJ1 = scanner.next();
        System.out.print (nomeJ1+" Nome do Filme:");
        nomeFilme = scanner.next();
        System.out.println (nomeJ1+" Agora as 5 pistas:");
        System.out.print (nomeJ1+" Pista 1:");
        nomeP1 = scanner.next();
        System.out.print (nomeJ1+" Pista 2:");
        nomeP2 = scanner.next();
        System.out.print (nomeJ1+" Pista 3:");
        nomeP3 = scanner.next();
        System.out.print (nomeJ1+" Pista 4:");
        nomeP4 = scanner.next();
        System.out.print (nomeJ1+" Pista 5:");
        nomeP5 = scanner.next();
        
        System.out.println ("Jogador 2,Digite seu nomee logo apos o nome do filme seguindo as pistas:");
        System.out.print ("Jogador 2:");
        nomeJ2 = scanner.next();
        
        do{
            if (numeroPistas == 0){
        System.out.print ("Nome do Filme:");
        resposta = scanner.next();
        if(resposta != nomeFilme){
        System.out.println (nomeJ2+" Errou");
        numeroPistas++;
        }
        
            }else if (numeroPistas == 1){
            System.out.print ("Dica 1: "+ nomeP1);
            
            System.out.print ("Nome do Filme:");
        resposta = scanner.next();
        if(resposta != nomeFilme){
        System.out.println (nomeJ2+" Errou");
        numeroPistas++;
        }
            
            }else if (numeroPistas == 2){
            System.out.println ("Dica 1: "+ nomeP1);
            System.out.println ("Dica 2: "+ nomeP2);
            System.out.print ("Nome do Filme:");
        resposta = scanner.next();
        if(resposta != nomeFilme){
        System.out.println (nomeJ2 +" Errou");
        numeroPistas++;
        }
            
            }else if (numeroPistas == 3){
            System.out.println ("Dica 1: "+ nomeP1);
            System.out.println ("Dica 2: "+ nomeP2);
            System.out.println ("Dica 3: "+ nomeP3);
            System.out.print ("Nome do Filme:");
        resposta = scanner.next();
        if(resposta != nomeFilme){
        System.out.println (nomeJ2 + " Errou");
        numeroPistas++;
        }
            
            }else if (numeroPistas == 4){
            System.out.print ("Dica 1: "+ nomeP1);
            System.out.println ("Dica 2: "+ nomeP2);
            System.out.println ("Dica 3: "+ nomeP3);
            System.out.println ("Dica 4: "+ nomeP4);
            
            System.out.print ("Nome do Filme:");
        resposta = scanner.next();
        if(resposta != nomeFilme){
        System.out.println (nomeJ2 + " Errou");
        numeroPistas++;
        }
            
            }else if (numeroPistas == 5){
            System.out.print ("Dica 1: "+ nomeP1);
             System.out.println ("Dica 2: "+ nomeP2);
            System.out.println ("Dica 3: "+ nomeP3);
            System.out.println ("Dica 4: "+ nomeP4);
            System.out.println ("Dica 5: "+ nomeP5);
            System.out.print ("Nome do Filme:");
        resposta = scanner.next();
        if(resposta != nomeFilme){
        System.out.println (nomeJ2 +" Errou");
        numeroPistas++;
        }
            
            }else{
             System.out.print (nomeJ2 + "Suas tentativas acabaram!:");
             System.out.print ("Nome do Filme:" + nomeFilme);
             System.exit(0);
             numeroPistas++;
            }
    
        } while (resposta != nomeFilme);
        System.out.print (nomeJ2 +"Acertou!");
        
        
    }
    
}
